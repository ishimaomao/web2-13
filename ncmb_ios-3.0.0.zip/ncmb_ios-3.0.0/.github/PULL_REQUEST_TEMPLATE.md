SDKの改善にご協力いただきありがとうございます。  
(Thank you for your support our SDK.)

プルリクエストを作成する場合は、developをターゲットにしてください。  
(Please select target branch to "develop" branch.)

可能な限り、修正時にはテストコードまたは動作確認手順を追加してください。  
(Please include test code or describe confirmation steps as possible.)

## 概要(Summary)

- Fixed #xx

## 動作確認手順(Step for Confirmation)

Run the unit test.
